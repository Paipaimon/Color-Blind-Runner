/**
 * 输入处理器
 * 监听键盘事件，将输入发送到服务器
 * Requirements: 2.5 - 客户端只发送输入命令，不修改本地游戏状态
 */

import { PlayerInput } from '../shared/messages.js';
import { WebSocketClient } from './websocket-client.js';

/**
 * 输入处理器类
 * 捕获键盘输入并通过 WebSocket 发送到服务器
 */
export class InputHandler {
  private wsClient: WebSocketClient;
  private currentInput: PlayerInput = {
    up: false,
    down: false,
    left: false,
    right: false
  };
  private previousInput: PlayerInput = { ...this.currentInput };
  private isBound = false;

  // 绑定的事件处理函数引用（用于解绑）
  private keydownHandler: (e: KeyboardEvent) => void;
  private keyupHandler: (e: KeyboardEvent) => void;

  constructor(wsClient: WebSocketClient) {
    this.wsClient = wsClient;
    this.keydownHandler = this.handleKeyDown.bind(this);
    this.keyupHandler = this.handleKeyUp.bind(this);
  }

  /**
   * 绑定键盘事件
   */
  bind(): void {
    if (this.isBound) return;

    window.addEventListener('keydown', this.keydownHandler);
    window.addEventListener('keyup', this.keyupHandler);
    this.isBound = true;
  }

  /**
   * 解绑键盘事件
   */
  unbind(): void {
    if (!this.isBound) return;

    window.removeEventListener('keydown', this.keydownHandler);
    window.removeEventListener('keyup', this.keyupHandler);
    this.isBound = false;

    // 重置输入状态
    this.currentInput = {
      up: false,
      down: false,
      left: false,
      right: false
    };
  }

  /**
   * 处理按键按下事件
   * 支持方向键和 WASD 键
   */
  private handleKeyDown(event: KeyboardEvent): void {
    const key = event.key.toLowerCase();
    let changed = false;

    switch (key) {
      case 'arrowup':
      case 'w':
        if (!this.currentInput.up) {
          this.currentInput.up = true;
          changed = true;
        }
        break;
      case 'arrowdown':
      case 's':
        if (!this.currentInput.down) {
          this.currentInput.down = true;
          changed = true;
        }
        break;
      case 'arrowleft':
      case 'a':
        if (!this.currentInput.left) {
          this.currentInput.left = true;
          changed = true;
        }
        break;
      case 'arrowright':
      case 'd':
        if (!this.currentInput.right) {
          this.currentInput.right = true;
          changed = true;
        }
        break;
      default:
        return; // 不处理其他按键
    }

    // 阻止默认行为（如页面滚动）
    event.preventDefault();

    // 只在输入变化时发送
    if (changed) {
      this.sendInputIfChanged();
    }
  }

  /**
   * 处理按键释放事件
   */
  private handleKeyUp(event: KeyboardEvent): void {
    const key = event.key.toLowerCase();
    let changed = false;

    switch (key) {
      case 'arrowup':
      case 'w':
        if (this.currentInput.up) {
          this.currentInput.up = false;
          changed = true;
        }
        break;
      case 'arrowdown':
      case 's':
        if (this.currentInput.down) {
          this.currentInput.down = false;
          changed = true;
        }
        break;
      case 'arrowleft':
      case 'a':
        if (this.currentInput.left) {
          this.currentInput.left = false;
          changed = true;
        }
        break;
      case 'arrowright':
      case 'd':
        if (this.currentInput.right) {
          this.currentInput.right = false;
          changed = true;
        }
        break;
      default:
        return;
    }

    event.preventDefault();

    if (changed) {
      this.sendInputIfChanged();
    }
  }

  /**
   * 检查输入是否变化，如果变化则发送到服务器
   * Requirements: 2.5 - 只发送输入命令
   */
  private sendInputIfChanged(): void {
    if (this.hasInputChanged()) {
      this.wsClient.sendInput({ ...this.currentInput });
      this.previousInput = { ...this.currentInput };
    }
  }

  /**
   * 检查输入是否与上次发送的不同
   */
  private hasInputChanged(): boolean {
    return (
      this.currentInput.up !== this.previousInput.up ||
      this.currentInput.down !== this.previousInput.down ||
      this.currentInput.left !== this.previousInput.left ||
      this.currentInput.right !== this.previousInput.right
    );
  }

  /**
   * 获取当前输入状态（只读）
   */
  getCurrentInput(): Readonly<PlayerInput> {
    return { ...this.currentInput };
  }
}
