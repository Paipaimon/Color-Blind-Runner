/**
 * 客户端入口
 * 集成 WebSocket 客户端、输入处理器和画布渲染器
 * Requirements: 客户端集成
 */

import { WebSocketClient } from './websocket-client.js';
import { InputHandler } from './input-handler.js';
import { CanvasRenderer } from './canvas-renderer.js';
import { ServerMessage, ServerMessageType, ClientMessageType } from '../shared/messages.js';
import { VisibleState, GameState, PlayerColor } from '../shared/types.js';
import { GAME_CONFIG } from '../shared/constants.js';

/**
 * 游戏客户端类
 * 协调所有客户端组件
 */
class GameClient {
  private wsClient: WebSocketClient;
  private inputHandler: InputHandler;
  private renderer: CanvasRenderer;
  private currentState: VisibleState | null = null;
  private myPlayerId: string | null = null;
  private myPlayerColor: PlayerColor | null = null;
  private roomId: string | null = null;
  private isReady = false;

  constructor() {
    // 获取服务器地址
    const serverUrl = this.getServerUrl();
    
    // 初始化组件
    this.wsClient = new WebSocketClient(serverUrl);
    this.inputHandler = new InputHandler(this.wsClient);
    this.renderer = new CanvasRenderer();

    // 设置消息处理
    this.setupMessageHandlers();
  }

  /**
   * 获取服务器 WebSocket 地址
   * 支持通过 URL 参数指定服务器地址：?server=192.168.1.100
   */
  private getServerUrl(): string {
    const urlParams = new URLSearchParams(window.location.search);
    const serverParam = urlParams.get('server');
    
    const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
    const host = serverParam || window.location.hostname || 'localhost';
    const port = GAME_CONFIG.DEFAULT_PORT;
    return `${protocol}//${host}:${port}`;
  }

  /**
   * 初始化游戏
   */
  async init(): Promise<void> {
    // 获取画布元素
    const canvas = document.getElementById('gameCanvas') as HTMLCanvasElement;
    if (!canvas) {
      throw new Error('找不到 gameCanvas 元素');
    }

    // 初始化渲染器
    this.renderer.init(canvas);

    // 绑定空格键用于准备/重新开始
    window.addEventListener('keydown', (e) => {
      if (e.code === 'Space') {
        e.preventDefault();
        this.handleSpaceKey();
      }
    });

    // 显示初始界面
    this.renderInitialScreen();

    // 连接服务器
    await this.connect();
  }

  /**
   * 连接到服务器
   */
  private async connect(): Promise<void> {
    try {
      this.updateStatus('正在连接服务器...');
      
      this.wsClient.onConnect(() => {
        this.updateStatus('已连接，正在加入房间...');
        // 自动加入房间
        this.wsClient.joinRoom();
      });

      this.wsClient.onDisconnect(() => {
        this.updateStatus('连接断开，请刷新页面重试');
        this.inputHandler.unbind();
      });

      this.wsClient.onError(() => {
        this.updateStatus('连接错误，请检查服务器是否运行');
      });

      await this.wsClient.connect();
    } catch (error) {
      this.updateStatus('无法连接到服务器');
      console.error('连接失败:', error);
    }
  }

  /**
   * 设置消息处理器
   */
  private setupMessageHandlers(): void {
    this.wsClient.onMessage((message: ServerMessage) => {
      switch (message.type) {
        case ServerMessageType.ROOM_JOINED:
          this.handleRoomJoined(message);
          break;
        case ServerMessageType.GAME_STATE:
          this.handleGameState(message);
          break;
        case ServerMessageType.COUNTDOWN:
          this.handleCountdown(message);
          break;
        case ServerMessageType.GAME_START:
          this.handleGameStart();
          break;
        case ServerMessageType.GAME_OVER:
          this.handleGameOver(message);
          break;
        case ServerMessageType.PLAYER_DIED:
          this.handlePlayerDied(message);
          break;
        case ServerMessageType.ERROR:
          this.handleError(message);
          break;
      }
    });
  }

  /**
   * 处理加入房间成功
   */
  private handleRoomJoined(message: { roomId: string; playerId: string; playerColor: PlayerColor; players?: { id: string }[] }): void {
    this.roomId = message.roomId;
    this.myPlayerId = message.playerId;
    this.myPlayerColor = message.playerColor;
    
    // 重置渲染器并设置玩家信息
    this.renderer.resetAll();
    this.renderer.setMyPlayer(message.playerId, message.playerColor);
    
    // 初始化当前状态为等待状态
    this.currentState = {
      players: [],
      obstacles: [],
      scrollSpeed: 0,
      gameState: GameState.WAITING
    };
    
    // 更新状态栏
    this.updateStatusBar(message.roomId, message.playerColor, message.players?.length || 1, '等待中');
  }

  /**
   * 获取颜色的中文名称
   */
  private getColorName(color: PlayerColor): string {
    const names: Record<PlayerColor, string> = {
      [PlayerColor.RED]: '红色',
      [PlayerColor.GREEN]: '绿色',
      [PlayerColor.BLUE]: '蓝色'
    };
    return names[color] || color;
  }

  /**
   * 处理游戏状态更新
   * Requirements: 8.3, 8.4 - 接收并渲染服务器状态
   */
  private handleGameState(message: { state: VisibleState }): void {
    this.currentState = message.state;
    // Requirements: 8.4 - 直接渲染接收到的状态，不做修改
    this.renderer.render(message.state);
    
    // 更新玩家数量
    if (this.roomId && this.myPlayerColor) {
      const playerCount = message.state.players.length;
      const status = message.state.gameState === GameState.PLAYING ? '游戏中' : '等待中';
      this.updateStatusBar(this.roomId, this.myPlayerColor, playerCount, status);
    }
  }

  /**
   * 处理倒计时
   */
  private handleCountdown(message: { seconds: number }): void {
    if (this.currentState) {
      this.currentState.countdown = message.seconds;
      this.currentState.gameState = GameState.COUNTDOWN;
      this.renderer.render(this.currentState);
    }
  }

  /**
   * 处理游戏开始
   */
  private handleGameStart(): void {
    // 绑定输入处理
    this.inputHandler.bind();
    if (this.roomId && this.myPlayerColor) {
      this.updateStatusBar(this.roomId, this.myPlayerColor, this.currentState?.players.length || 0, '游戏中');
    }
  }

  /**
   * 处理游戏结束
   */
  private handleGameOver(message: { winners: string[]; finalState: VisibleState }): void {
    this.inputHandler.unbind();
    this.isReady = false;
    this.currentState = message.finalState;
    this.renderer.render(message.finalState);

    if (this.roomId && this.myPlayerColor) {
      this.updateStatusBar(this.roomId, this.myPlayerColor, 0, '已结束');
    }
  }

  /**
   * 处理玩家死亡
   */
  private handlePlayerDied(message: { playerId: string }): void {
    if (message.playerId === this.myPlayerId) {
      if (this.roomId && this.myPlayerColor) {
        this.updateStatusBar(this.roomId, this.myPlayerColor, this.currentState?.players.length || 0, '已死亡');
      }
    }
  }

  /**
   * 处理错误消息
   */
  private handleError(message: { code: string; message: string }): void {
    this.updateStatus(`错误: ${message.message}`);
    console.error('服务器错误:', message);
  }

  /**
   * 处理空格键
   */
  private handleSpaceKey(): void {
    if (!this.currentState) return;

    if (this.currentState.gameState === GameState.WAITING && !this.isReady) {
      this.wsClient.sendReady();
      this.isReady = true;
      if (this.roomId && this.myPlayerColor) {
        this.updateStatusBar(this.roomId, this.myPlayerColor, this.currentState.players.length, '已准备');
      }
    } else if (this.currentState.gameState === GameState.GAME_OVER) {
      // 重置渲染器状态
      this.renderer.resetAll();
      // 重新加入房间
      this.wsClient.joinRoom();
      this.isReady = false;
    }
  }

  /**
   * 渲染初始界面
   */
  private renderInitialScreen(): void {
    const defaultState: VisibleState = {
      players: [],
      obstacles: [],
      scrollSpeed: 0,
      gameState: GameState.WAITING
    };
    this.renderer.render(defaultState);
  }

  /**
   * 更新状态显示
   */
  private updateStatus(text: string): void {
    console.log('[状态]', text);
  }

  /**
   * 更新状态栏
   */
  private updateStatusBar(roomId: string, color: PlayerColor, playerCount: number, status: string): void {
    // 更新房间ID
    const roomIdEl = document.getElementById('roomId');
    if (roomIdEl) {
      roomIdEl.textContent = roomId.substring(0, 8);
    }

    // 更新颜色点
    const colorDot = document.getElementById('colorDot');
    if (colorDot) {
      colorDot.className = 'color-dot';
      switch (color) {
        case PlayerColor.RED:
          colorDot.classList.add('color-red');
          break;
        case PlayerColor.GREEN:
          colorDot.classList.add('color-green');
          break;
        case PlayerColor.BLUE:
          colorDot.classList.add('color-blue');
          break;
      }
    }

    // 更新玩家数量
    const playerCountEl = document.getElementById('playerCount');
    if (playerCountEl) {
      playerCountEl.textContent = `${playerCount}/${GAME_CONFIG.MAX_PLAYERS}`;
    }

    // 更新游戏状态
    const gameStatusEl = document.getElementById('gameStatus');
    if (gameStatusEl) {
      gameStatusEl.textContent = status;
    }
  }
}

// 页面加载完成后初始化游戏
window.addEventListener('DOMContentLoaded', async () => {
  const client = new GameClient();
  try {
    await client.init();
  } catch (error) {
    console.error('游戏初始化失败:', error);
  }
});
